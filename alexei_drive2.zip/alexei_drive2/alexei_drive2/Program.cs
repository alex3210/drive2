﻿using System;
using System.Collections.Generic;

namespace alexei_drive2
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //instantiate IDictionary
            IDictionary<string, int> d = new Dict<string, int>();

            //Add Key-Value pairs in arbitrary order
            d.Add("Bob", 1);
            d.Add("Bill", 2);
            d.Add("Tim", 3);
            d.Add("Jan", 4);
            d.Add("Jill", 5);
            d.Add("Sarah", 6);
            d.Add("Ann", 7);
            d.Add("Alex", 8);
            d.Add("John", 9);

            //print keys and values (now they should be in order)
            foreach (string s in d.Keys())
            {
                Console.WriteLine("{0} : {1}", s, d.GetValue(s));
            }

            Console.WriteLine();

            //test methods
            Console.WriteLine("ContainsKey({0}): {1}", "Bob", d.ContainsKey("Bob"));
            Console.WriteLine("ContainsValue({0}): {1}", 3, d.ContainsValue(3));
            int val;
            Console.WriteLine("TryGetValue({0}): {1}; Value: {2}", "Sarah", d.TryGetValue("Sarah", out val), val);
            Console.WriteLine("Remove({0}): {1}", "Bill", d.Remove("Bill"));
            Console.WriteLine("ContainsKey({0}) after removal ({1}): {2}", "Bill", "[Bill, 2]", d.ContainsValue(2));
            Console.WriteLine("ContainsValue({0}) after removal ({1}): {2}", 2, "[Bill, 2]", d.ContainsValue(2));
            Console.WriteLine("Equals({0}): {1}", "d.GetValue(\"Alex\").Equals(d.GetValue(\"Bob\")", d.GetValue("Alex").Equals(d.GetValue("Bob") ));

            d.SetValue("Jan", 3);
            Console.WriteLine("Equals({0}) after modification({1}): {2}", "d.GetValue(\"Tim\").Equals(d.GetValue(\"Jan\")", "d.SetValue(\"Jan\", 3)", d.GetValue("Tim").Equals(d.GetValue("Jan")));

            Console.WriteLine("GetKeyValuePair({0}): {1}", 0, d.GetKeyValuePair(0));

            d.SetValue("Bob", 100);
            Console.WriteLine("GetValue({0}) after modification({1}): {2}", "Bob", "d.SetValue(\"Bob\", 100)", d.GetValue("Bob"));

            Console.WriteLine("Count: {0}", d.Count());
        }
    }


    public class Dict<TKey, Tval> : IDictionary<TKey, Tval>
    {
        public IDictionary<TKey, Tval> dict;
    }


    public class IDictionary<Tkey, Tval>
    {
        //I used a SortedDictionary to implement a Dictionary, sorted by key
        //SortedDictionary uses a tree data structure, unlike Dictionary, which uses a hash table
        //this is slower than a hash table (O(1) read/insert), but still relatively fast (O(logn) read/insert)
        private SortedDictionary<Tkey, Tval> tree = new SortedDictionary<Tkey, Tval>();


        //add custom methods: GetValue, SetValue, GetKeyValuePair
        public Tval GetValue(Tkey key)
        {
            Tval val;
            if (tree.TryGetValue(key, out val))
            {
                return tree[key];
            }
            return val;
        }

        public void SetValue(Tkey key, Tval value)
        {
            if (tree.ContainsKey(key))
            {
                tree[key] = value;
            }
        }

        public KeyValuePair<Tkey, Tval> GetKeyValuePair(int n)
        {
            int i = 0;
            foreach (KeyValuePair<Tkey, Tval> s in tree)
            {
                if (i == n)
                {
                    return s;
                }
                i++;
            }

            return default(KeyValuePair<Tkey, Tval>);
        }


        //re-implement all methods from SortedDictionary
        public void Add(Tkey key, Tval value)
        {
            tree.Add(key, value);
        }

        public Boolean Remove(Tkey key)
        {
            return tree.Remove(key);
        }

        public Boolean TryGetValue(Tkey key, out Tval value)
        {
            return tree.TryGetValue(key, out value);
        }

        public Boolean ContainsKey(Tkey key)
        {
            return tree.ContainsKey(key);
        }

        public Boolean ContainsValue(Tval value)
        {
            return tree.ContainsValue(value);
        }

        public void CopyTo(KeyValuePair<Tkey, Tval>[] array, int arrayIndex)
        {
            tree.CopyTo(array, arrayIndex);
        }

        public SortedDictionary<Tkey, Tval>.KeyCollection Keys()
        {
            return tree.Keys;
        }

        public SortedDictionary<Tkey, Tval>.ValueCollection Values()
        {
            return tree.Values;
        }

        public void Clear()
        {
            tree.Clear();
        }

        public IComparer<Tkey> Comparer()
        {
            return tree.Comparer;
        }

        public int Count()
        {
            return tree.Count;
        }

        public SortedDictionary<Tkey, Tval>.Enumerator GetEnumerator()
        {
            return tree.GetEnumerator();
        }

        public int GetHashCode()
        {
            return tree.GetHashCode();
        }

        public Type GetType()
        {
            return tree.GetType();
        }

        public Boolean Equals(object obj)
        {
            return tree.Equals(obj);
        }

        public string ToString()
        {
            return tree.ToString();
        }
    }
}